Compile is pretty simple, just a regular C program:

gcc smallsh.c -o smallsh
